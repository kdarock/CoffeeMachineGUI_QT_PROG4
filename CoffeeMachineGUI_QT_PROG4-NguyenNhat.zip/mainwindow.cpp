#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtWidgets>
#include <QColor>
#include <QLabel>
#include <QPixmap>
#include "StateMachine.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    logDisplay = ui->Logging;
    display = ui->user_info;

    coffeeMachine = new StateMachine(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setLogger(const QString &text) {
    logDisplay->moveCursor(QTextCursor::End);
    logDisplay->insertPlainText("\n" + text);
    logDisplay->moveCursor(QTextCursor::End);
}
void MainWindow::setDisplay(const QString &text){
    display->setText(text);
    display->update();
}


void MainWindow::on_startButton_clicked()
{
    coffeeMachine -> handleState(E_customer);
}


void MainWindow::on_adminMode_clicked()
{
    coffeeMachine->handleState(E_adminLogin);
    setLogger("SYSTEM: Admin Mode activated. Refilled ingredients and change vault.");
}


void MainWindow::on_americano_clicked()
{
    coffeeMachine -> handleState(E_chooseAmericano);
}


void MainWindow::on_latte_clicked()
{
    coffeeMachine -> handleState(E_chooseLatte);
}


void MainWindow::on_cappuccino_clicked()
{
    coffeeMachine -> handleState(E_chooseCappuccino);
}


void MainWindow::on_twentyFive_clicked()
{
    coffeeMachine -> handleState(E_in25c);
}


void MainWindow::on_fifty_clicked()
{
    coffeeMachine -> handleState(E_in50c);
}


void MainWindow::on_one_clicked()
{
    coffeeMachine -> handleState(E_in1e);
}


void MainWindow::on_confirm_clicked()
{
    coffeeMachine->handleState(E_accept);
    coffeeMachine->handleState(E_confirm);
}


void MainWindow::on_cancel_clicked()
{
    coffeeMachine->handleState(E_refund);
    coffeeMachine->handleState(E_cancel);
}


void MainWindow::on_incorrect_clicked()
{
    setLogger("ERROR: Coin not recognised. Returning coin to customer.");
}

