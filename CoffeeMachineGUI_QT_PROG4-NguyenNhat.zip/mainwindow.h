#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDialog>
#include "StateMachine.h"
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
class QAction;
class QDialogButtonBox;
class QGroupBox;
class QLabel;
class QMenu;
class QMenuBar;
class QPushButton;
class QTextEdit;
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void setLogger(const QString& text);
    void setDisplay(const QString &text);
    StateMachine *coffeeMachine;
private slots:
    void on_fifty_clicked();

    void on_startButton_clicked();

    void on_adminMode_clicked();

    void on_americano_clicked();

    void on_latte_clicked();

    void on_cappuccino_clicked();

    void on_twentyFive_clicked();

    void on_one_clicked();

    void on_confirm_clicked();

    void on_cancel_clicked();

    void on_incorrect_clicked();

private:
    Ui::MainWindow *ui;
    QTextEdit *logDisplay;
    QTextEdit *display;
};
#endif // MAINWINDOW_H
