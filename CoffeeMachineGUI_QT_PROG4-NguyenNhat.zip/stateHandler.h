#ifndef STATEHANDLER_H
#define STATEHANDLER_H
#include "MainWindow.h"
#include "StateMachine.h"
#include <QTextEdit>
#include <QPushButton>
#include <iostream>
#include <sstream>


#endif // STATEHANDLER_H
