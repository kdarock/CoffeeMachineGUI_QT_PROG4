
#ifndef STATEMACHINE_H
#define STATEMACHINE_H

typedef int error_t;
typedef enum {NOERR} error_e;

typedef enum{S_NO,S_initialiseHardware,S_START,S_idle,S_adminMode,S_chooseCoffee,S_Latte,S_Cappuccino,S_Americano,S_confirmation,S_waitForMoney,
            S_50c,S_1e,S_25c,S_makeCoffee,S_giveCoffee,S_cancel,S_refund,S_confirmation2} state_e;


typedef enum{E_SEQ,E_NO,E_customer,E_adminLogin,E_chooseAmericano,E_chooseLatte,E_chooseCappuccino,
               E_americanoChosen,E_latteChosen,E_cappuccinoChosen,E_accept,E_cancel,
               E_waitForMoney,E_refund,E_in50c,E_in1e,E_in25c,E_enough,E_notEnough, E_refill,E_confirm}event_e;
typedef enum{Cappuccino,Americano,Latte,Null}coffee_e;
#define AVAILABLE_COFFEE 10
#define AVAILABLE_MILK 10
#define AVAILABLE_CHANGE 100

#define PRICE_CAPPUCCINO 75
#define PRICE_AMERICANO 50
#define PRICE_LATTE 100


class MainWindow; //explanation needed
typedef struct{
    event_e eventOut;
    state_e nextState;

}stateResult_t;

class StateMachine{
public:
    StateMachine(MainWindow* pDialog): /*explanation needed:This is a constructor called when a stateMachine object is declared.*/
        pDialog(pDialog),/*explanation needed: the pDialog outside the parentheses is the one declared in the private*/
        currentState(S_START), money(0.0), availableCoffee(AVAILABLE_COFFEE),availableMilk(AVAILABLE_MILK),availableChange(AVAILABLE_CHANGE),
        priceLatte(PRICE_LATTE),priceCappuccino(PRICE_CAPPUCCINO),priceAmericano(PRICE_AMERICANO),priceSumCoffee(0)    {}
    ~StateMachine(){}//deconstructor
    event_e handleState(event_e eventIn);
    state_e getCurrentState() const {return currentState;}
    stateResult_t stateRoute(state_e state,event_e eventIn);

private:
    /*Declares a pointer pDialog to the main window
     By storing this address the State macine knows exactly where to
    send logs without copying the whole main window in to its memory */
    MainWindow* pDialog;
    state_e currentState;
    int money;
    int availableCoffee;
    int availableMilk;
    int availableChange;
    const int priceLatte;
    const int priceCappuccino;
    const int priceAmericano;
    int priceSumCoffee;
    coffee_e chosenCoffee;
    event_e stateMachine(event_e eventIn);
    stateResult_t handleOrder(const int moneyIn);
    event_e cancel(void);
    stateResult_t giveChange(void);

    /*SPECIFIC STATE HANDLERS*/
    stateResult_t handleStart(void);//check
    stateResult_t handleInit(void);//check
    stateResult_t handleIdle(event_e e);//check
    stateResult_t handleChooseCoffee(event_e e);//check
    stateResult_t handleAdminMode(void);//check
    stateResult_t handleAmericano(void);//check
    stateResult_t handleLatte(void);//check
    stateResult_t handleCappuccino(void);//check
    stateResult_t handleConfirmation(event_e e);//check
    stateResult_t handleWaitForMoney(event_e e);
    stateResult_t handleMakeCoffee(void);//check
    stateResult_t handleGiveCoffee(void);//check
    stateResult_t handleCancel(void);//check
    stateResult_t handleRefund(void);//check
    stateResult_t handleConfirmation2(event_e e);//check
};


#endif // STATEMACHINE_H
