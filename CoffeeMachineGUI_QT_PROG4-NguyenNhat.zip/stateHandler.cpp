#include "stateMachine.h"
#include "stateHandler.h"
#include <iostream>
#define MILK_LATTE 3
#define COFFEE_LATTE 4
#define MILK_CAPPUCCINO 2
#define COFFEE_CAPPUCCINO 2
#define MILK_AMERICANO 3
#define COFFEE_AMERICANO 1
stateResult_t StateMachine::handleStart(void){
    pDialog->setLogger("State: S_start");
    return {E_SEQ,S_initialiseHardware};
}

stateResult_t StateMachine::handleInit(void){
    pDialog->setLogger("State: S_initialiseHardware");
    return{E_NO,S_idle};
}
stateResult_t StateMachine::handleChooseCoffee(event_e e){
    switch(e){
    case E_chooseAmericano:
        return {E_SEQ,S_Americano};
    case E_chooseLatte:
        return {E_SEQ,S_Latte};
    case E_chooseCappuccino:
        return {E_SEQ,S_Cappuccino};
    default:
        return {E_NO,S_NO};
        pDialog->setLogger("S_chooseCoffee: ERROR");
    }
}

stateResult_t StateMachine::handleAdminMode(void){
    availableCoffee = AVAILABLE_COFFEE;
    availableMilk = AVAILABLE_MILK;
    availableChange = AVAILABLE_CHANGE;

    return {E_NO,S_idle};
}

stateResult_t StateMachine::handleIdle(event_e e){
    switch(e){
        case E_customer:
            return {E_SEQ,S_chooseCoffee};
        case E_adminLogin:
            return {E_SEQ,S_adminMode};
        default:
        pDialog->setLogger("S_choose: ERROR");
            return {E_NO,S_NO};
    }
}

stateResult_t StateMachine::handleAmericano(void){
    chosenCoffee=Americano;
    priceSumCoffee+=priceAmericano;
    pDialog->setDisplay("Price: 50 cents");
    return {E_NO,S_confirmation};
}
stateResult_t StateMachine::handleCappuccino(void){
    chosenCoffee=Cappuccino;
    priceSumCoffee+=priceCappuccino;
    pDialog->setDisplay("Price: 75 cents");
    return {E_NO,S_confirmation};
}

stateResult_t StateMachine::handleLatte(void){
    chosenCoffee=Latte;
    priceSumCoffee+=priceLatte;
    return {E_NO,S_confirmation};
}
stateResult_t StateMachine::handleConfirmation(event_e e){
    switch(e)
    {
    case E_accept:
        return{E_SEQ,S_waitForMoney};
    case E_cancel:
        return{E_SEQ,S_waitForMoney};
    default:
        pDialog->setLogger("S_confirmation: ERROR");
        return{E_NO,S_NO};
    }
}
stateResult_t StateMachine::handleCancel(void){
    chosenCoffee=Null;
    priceSumCoffee=0;
    return{E_SEQ,S_idle};
}
stateResult_t StateMachine::handleRefund(void){
    money=0;
    return{E_SEQ,S_cancel};
}
stateResult_t StateMachine::handleMakeCoffee(void){
    if(chosenCoffee==Latte){
        availableCoffee-=COFFEE_LATTE;
        availableMilk-=MILK_LATTE;
    }
    else if(chosenCoffee==Cappuccino){
        availableCoffee-=COFFEE_CAPPUCCINO;
        availableMilk-=MILK_CAPPUCCINO;
    }
    else if(chosenCoffee==Americano){
        availableCoffee-=COFFEE_AMERICANO;
        availableMilk-=MILK_AMERICANO;
    }
    else{
        availableCoffee-=0;
        availableMilk-=0;
    }
    return {E_SEQ,S_giveCoffee};
}

stateResult_t StateMachine::handleGiveCoffee(void){
    giveChange();
    return {E_SEQ,S_idle};
}
stateResult_t StateMachine::handleWaitForMoney(event_e e){
    switch(e){
    case E_in1e:
        return {E_SEQ,S_1e};
    case E_in50c:
        return {E_SEQ,S_50c};
    case E_in25c:
        return {E_SEQ,S_25c};
    case E_notEnough:
        return{E_NO,S_waitForMoney};
    default:
        pDialog->setLogger("S_waitForMoney: SYSTEM ERROR");
        return{E_NO,S_NO};
    }
}

stateResult_t StateMachine::handleConfirmation2(event_e e){
    switch(e){
    case E_confirm:
        return {E_SEQ,S_makeCoffee};
    case E_refund:
        return {E_SEQ,S_refund};
    default:
        pDialog->setLogger("S_confirmation2: SYSTEM ERROR");
        return{E_NO,S_NO};
    }
}
