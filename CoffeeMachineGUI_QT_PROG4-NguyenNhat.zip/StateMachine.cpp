#include "MainWindow.h"
#include "StateMachine.h"
#include <QTextEdit>
#include <QPushButton>
#include <iostream>
#include <sstream>
#include "StateHandler.h"
#include "ui_mainwindow.h"

/*Make more function (max about 30 lines)->kinda means we have to put them in separate file
Take a look at hardcoded line (use #define)
Make the uml a little less basic :)
*/

event_e StateMachine::handleState(event_e eventIn)
{
    if(eventIn != E_NO){
        stateResult_t r =stateRoute(currentState,eventIn);
        currentState=r.nextState;
        return r.eventOut;
    }
}
stateResult_t StateMachine::stateRoute(state_e state, event_e eventIn){

    switch(state){
        case S_START:
            return handleInit();
        case S_initialiseHardware:
            return handleInit();
        case S_idle:
            return handleIdle(eventIn);
        case S_chooseCoffee:
            return handleChooseCoffee(eventIn);
        case S_adminMode:
            return handleAdminMode();
        case S_Americano:
            return handleAmericano();
        case S_Latte:
            return handleLatte();
        case S_Cappuccino:
            return handleCappuccino();
        case S_confirmation:
            return handleConfirmation(eventIn);
        case S_waitForMoney:
            return handleWaitForMoney(eventIn);
        case S_1e:
            return handleOrder(100);
        case S_50c:
            return handleOrder(50);
        case S_25c:
            return handleOrder(25);
        case S_makeCoffee:
            return handleMakeCoffee();
        case S_giveCoffee:
            return handleGiveCoffee();
        case S_confirmation2:
            return handleConfirmation2(eventIn);
        default:
            return {E_NO,S_NO};
             printf("SYSTEM ERROR");
    }
}



stateResult_t StateMachine::handleOrder(const int moneyIn)
{
    money+=moneyIn;
    if(chosenCoffee==Americano){
        if(money >=priceSumCoffee){
            return {E_enough,S_makeCoffee};
        }
        else return {E_notEnough,S_waitForMoney};
    }

    if(chosenCoffee==Latte){
        if(money >=priceSumCoffee){
            return {E_enough,S_makeCoffee};
        }
        else return {E_notEnough,S_waitForMoney};
    }
    if(chosenCoffee==Cappuccino){
        if(money >=priceSumCoffee){
            return {E_enough,S_makeCoffee};
        }
        else return {E_notEnough,S_waitForMoney};
    }
    else return  {E_notEnough,S_waitForMoney};
}

stateResult_t StateMachine::giveChange(void){
    if((money-priceSumCoffee)<=availableChange){
        money - priceSumCoffee;
        return {E_SEQ,S_idle};
    }
    else{
        pDialog->setLogger("Error: not enough change");
        return {E_SEQ,S_NO}; //might need better solution.
    }
}

